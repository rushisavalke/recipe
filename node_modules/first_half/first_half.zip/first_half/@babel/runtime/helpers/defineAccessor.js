function _defineAccessor(e, r, n, t) {
  var c = {
    configurable: !0,
    enumerable: !0
  };
  return c[e] = t, Object.defineProperty(r, n, c);
}
module.exports = _defineAccessor, module.exports.__esModule = true, module.exports["default"] = module.exports;