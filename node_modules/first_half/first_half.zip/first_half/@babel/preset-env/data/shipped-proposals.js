const { pluginSyntaxMap, proposalPlugins, proposalSyntaxPlugins } = require("../lib/shipped-proposals");
module.exports = { pluginSyntaxMap, proposalPlugins, proposalSyntaxPlugins };
