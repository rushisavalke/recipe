# Changes to PostCSS Text Decoration Shorthand

### 1.0.0  (August 15, 2022)

- Initial version
