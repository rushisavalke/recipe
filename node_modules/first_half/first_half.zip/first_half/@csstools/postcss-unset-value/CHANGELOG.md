# Changes to PostCSS Unset Value

### 1.0.2 (July 8, 2022)

- Fixed: Case insensitive property and keyword matching.

### 1.0.1 (May 11, 2022)

- No longer converts `all: unset;` to `all: initial;`. `all: unset` is now ignored.

### 1.0.0 (February 21, 2022)

- Initial version
