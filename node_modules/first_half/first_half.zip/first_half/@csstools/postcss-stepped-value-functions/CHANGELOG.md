# Changes to PostCSS Stepped Value Functions

### 1.0.1 (July 8, 2022)

- Fix case insensitive matching.

### 1.0.0 (May 2, 2022)

- Initial version
